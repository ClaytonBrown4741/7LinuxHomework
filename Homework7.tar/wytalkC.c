/*
* wytalkC.c
* Author: Clayton Brown
* Date: April 3, 2023
*
* COSC 3750, Homework 7
*
* This is an altered version of that talk utility, and behaves
* in a similar way. When used in conjecture with a daemon
* process, it sets up communication between the two. When
* either of them quit, the program ends
*
*/

#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<string.h>
#include<netdb.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>

#include"socketfun.h"

int main(int argc, char **argv, char **envp){
  // Variables
  int sockfd=0;
  int testChecker=0;
  char currentChar='\0';
  char input[4028];
  char userInput[4027];
  char output[4028];
  sockfd=request_connection(argv[1], 51100);
  if (sockfd==1){
    fprintf(stderr, "Error when connecting with socket\n");
    return 0;
  }
  // This loop will repeat sa long as both processes are running
  while (1){
    // Reset some string variables
    strncpy(userInput, "", 4028);
    strncpy(input, "", 4028);
    strncpy(output, "", 4028);


    // Get user input
    fgets(output, 4028, stdin);
    // If the client quits stdin, quit. 
    if (feof(stdin)){
      return 0;
    }
    send(sockfd, output, 256, 0);
    

    // Get info from the daemon
    currentChar='\0';
    // Read input one char at a time until \n is enountered
    while (currentChar!='\n'){
      testChecker=recv(sockfd,input,1,0);
      // If the socket it closed, end the program
      if (testChecker==0){
        return 0;
      }
      currentChar=input[0];
      printf("%s", input);
    }
   
    currentChar='\0';
  }
}

